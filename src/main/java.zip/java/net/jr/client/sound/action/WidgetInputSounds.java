package net.jr.client.sound.action;

import net.jr.client.components.navigation.UiActionFeedback;

public final class WidgetInputSounds {
    private WidgetInputSounds() {
    }

    public static void reportPointerClickFeedback(UiActionFeedback feedback) {
        InputActionSounds.play(feedback == null ? UiActionFeedback.NONE : feedback);
    }

    public static void playPointerDragFeedback(UiActionFeedback feedback) {
        InputActionSounds.play(feedback);
    }
}
