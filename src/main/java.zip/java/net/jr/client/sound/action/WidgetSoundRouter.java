package net.jr.client.sound.action;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.AbstractWidget;
import net.minecraft.client.gui.screens.Screen;

public final class WidgetSoundRouter {
    private static final ThreadLocal<Boolean> PENDING_PRESS = new ThreadLocal<>();

    private WidgetSoundRouter() {
    }

    public static void playDownSound(AbstractWidget widget) {
        if (widget instanceof AbstractSliderButton) {
            return;
        }
        if (PENDING_PRESS.get() == null) {
            InputActionSounds.playClick();
        } else {
            PENDING_PRESS.set(true);
        }
    }

    public static void beginPress() {
        PENDING_PRESS.set(false);
    }

    public static void finishPress(Screen sourceScreen, boolean handled) {
        boolean play = handled
                && Boolean.TRUE.equals(PENDING_PRESS.get())
                && Minecraft.getInstance().gui.screen() == sourceScreen;
        PENDING_PRESS.remove();
        if (play) {
            InputActionSounds.playClick();
        }
    }
}
