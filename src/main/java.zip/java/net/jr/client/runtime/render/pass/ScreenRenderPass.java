package net.jr.client.runtime.render.pass;

import java.util.Stack;
import net.jr.client.input.InputApi;
import net.jr.client.runtime.input.LocalGamepadInputHandler;
import net.jr.client.runtime.ClientRuntime;
import net.jr.client.runtime.context.SlotScope;
import net.jr.client.runtime.input.LocalScreenInput;
import net.jr.client.runtime.slot.LocalClientSlot;
import net.jr.client.runtime.ui.SecondaryWorldLoadingScreen;
import net.jr.client.runtime.viewport.ViewportArea;
import net.jr.client.runtime.viewport.ViewportGuiScale;
import net.jr.client.ui.navigation.UiInputModeController;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import org.jetbrains.annotations.Nullable;
import net.neoforged.neoforge.client.ClientHooks;

public final class ScreenRenderPass {
    private ScreenRenderPass() {
    }

    @Nullable
    public static Screen extract(
        Minecraft minecraft,
        GuiGraphicsExtractor graphics,
        float partialTick
    ) {
        int slotId = SlotScope.requireId();
        ClientRuntime runtime = ClientRuntime.INSTANCE;
        if (minecraft.gui.overlay() != null || !runtime.viewports().hasViewport(slotId)) {
            return null;
        }

        UiInputModeController.updateCurrentClientFrame(minecraft);
        LocalClientSlot slot = runtime.slots().slot(slotId);
        ViewportArea viewport = runtime.viewports().viewport(slotId);
        Screen screen = slot.screenState().screen();

        if (screen == null && SecondaryWorldLoadingScreen.shouldPresent(slot)) {
            screen = SecondaryWorldLoadingScreen.forSlot(slotId);
            int width = ViewportGuiScale.logicalWidth(viewport);
            int height = ViewportGuiScale.logicalHeight(viewport);
            if (screen.width != width || screen.height != height) {
                screen.init(width, height);
            }
        }

        if (screen == null) {
            return null;
        }

        Screen renderScreen = screen;
        int mouseX = logicalMouseX(minecraft, slotId, viewport);
        int mouseY = logicalMouseY(minecraft, slotId, viewport);
        LocalScreenInput.runEvent(
            () -> ClientHooks.extractScreen(
                renderScreen,
                new Stack<>(),
                graphics,
                mouseX,
                mouseY,
                partialTick
            ),
            "Extracting slot screen render state",
            renderScreen.getClass().getCanonicalName()
        );

        LocalGamepadInputHandler.trackFocusedCursorDuringScroll(renderScreen);
        ControlHintRenderPass.renderScreen(renderScreen, graphics);
        return renderScreen;
    }

    private static int logicalMouseX(
        Minecraft minecraft,
        int slotId,
        ViewportArea viewport
    ) {
        if (LocalGamepadInputHandler.isControllerCursorActive(slotId)) {
            return LocalGamepadInputHandler.resolveScreenMouseX(
                slotId,
                (int)Math.round(LocalGamepadInputHandler.cursorX(slotId))
            );
        }
        if (!InputApi.canPhysicalMouseDriveSlot(slotId)) {
            return Integer.MIN_VALUE;
        }
        int localGuiX = LocalGamepadInputHandler.resolveScreenMouseX(
            slotId,
            (int)viewport.windowMouseToLocalGuiX(minecraft.mouseHandler.xpos())
        );
        return ViewportGuiScale.logicalMouseX(viewport, localGuiX);
    }

    private static int logicalMouseY(
        Minecraft minecraft,
        int slotId,
        ViewportArea viewport
    ) {
        if (LocalGamepadInputHandler.isControllerCursorActive(slotId)) {
            return LocalGamepadInputHandler.resolveScreenMouseY(
                slotId,
                (int)Math.round(LocalGamepadInputHandler.cursorY(slotId))
            );
        }
        if (!InputApi.canPhysicalMouseDriveSlot(slotId)) {
            return Integer.MIN_VALUE;
        }
        int localGuiY = LocalGamepadInputHandler.resolveScreenMouseY(
            slotId,
            (int)viewport.windowMouseToLocalGuiY(minecraft.mouseHandler.ypos())
        );
        return ViewportGuiScale.logicalMouseY(viewport, localGuiY);
    }
}
