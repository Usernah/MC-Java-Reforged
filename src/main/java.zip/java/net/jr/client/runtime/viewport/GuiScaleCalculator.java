package net.jr.client.runtime.viewport;

import net.jr.client.runtime.ClientRuntime;
import net.jr.client.ui.presentation.UiPresentation;

public final class GuiScaleCalculator {
    private static final int STANDARD_BASE_WIDTH = 320;
    private static final int STANDARD_BASE_HEIGHT = 240;
    private static final int PORTABLE_BASE_WIDTH = 280;
    private static final int PORTABLE_BASE_HEIGHT = 200;

    private GuiScaleCalculator() {
    }

    public static int resolve(int width, int height, int requestedScale, boolean enforceUnicode) {
        boolean smallMetrics = usesSmallMetrics();
        int baseWidth = smallMetrics ? PORTABLE_BASE_WIDTH : STANDARD_BASE_WIDTH;
        int baseHeight = smallMetrics ? PORTABLE_BASE_HEIGHT : STANDARD_BASE_HEIGHT;
        return resolve(width, height, requestedScale, enforceUnicode, baseWidth, baseHeight);
    }

    public static int resolveStandard(
        int width,
        int height,
        int requestedScale,
        boolean enforceUnicode
    ) {
        return resolve(
            width,
            height,
            requestedScale,
            enforceUnicode,
            STANDARD_BASE_WIDTH,
            STANDARD_BASE_HEIGHT
        );
    }

    private static int resolve(
        int width,
        int height,
        int requestedScale,
        boolean enforceUnicode,
        int baseWidth,
        int baseHeight
    ) {
        int scale = 1;

        while (scale != requestedScale
            && scale < width
            && scale < height
            && width / (scale + 1) >= baseWidth
            && height / (scale + 1) >= baseHeight) {
            scale++;
        }
        if (enforceUnicode && scale % 2 != 0) {
            scale++;
        }
        return scale;
    }

    private static boolean usesSmallMetrics() {
        return UiPresentation.isPortable();
    }

    public static int maximumForSlot(int slotId, boolean enforceUnicode) {
        if (!ClientRuntime.INSTANCE.viewports().hasWindowMetrics()) {
            return 1;
        }
        var viewports = ClientRuntime.INSTANCE.viewports();
        if (viewports.hasViewport(slotId)) {
            var viewport = viewports.viewport(slotId);
            return resolve(viewport.glWidth(), viewport.glHeight(), 0, enforceUnicode);
        }
        var metrics = ClientRuntime.INSTANCE.viewports().windowMetrics();
        return resolve(metrics.framebufferWidth(), metrics.framebufferHeight(), 0, enforceUnicode);
    }
}
