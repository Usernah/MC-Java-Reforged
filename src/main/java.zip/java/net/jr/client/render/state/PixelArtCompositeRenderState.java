package net.jr.client.render.state;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.jr.client.render.pipeline.ModRenderPipelines;
import net.minecraft.client.gui.navigation.ScreenRectangle;
import net.minecraft.client.gui.render.TextureSetup;
import net.minecraft.client.renderer.state.gui.GuiElementRenderState;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2fc;

public record PixelArtCompositeRenderState(
    RenderPipeline pipeline,
    TextureSetup textureSetup,
    Matrix3x2fc pose,
    int x0,
    int y0,
    int x1,
    int y1,
    float u0,
    float u1,
    float v0,
    float v1,
    float pixelBias,
    int color,
    @Nullable ScreenRectangle scissorArea,
    @Nullable ScreenRectangle bounds
) implements GuiElementRenderState {
    public PixelArtCompositeRenderState(
        TextureSetup textureSetup,
        Matrix3x2fc pose,
        int x0,
        int y0,
        int x1,
        int y1,
        float u0,
        float u1,
        float v0,
        float v1,
        float pixelBias,
        int color,
        @Nullable ScreenRectangle scissorArea
    ) {
        this(
            ModRenderPipelines.PIXEL_ART_COMPOSITE,
            textureSetup,
            pose,
            x0,
            y0,
            x1,
            y1,
            u0,
            u1,
            v0,
            v1,
            pixelBias,
            color,
            scissorArea,
            bounds(x0, y0, x1, y1, pose, scissorArea)
        );
    }

    @Override
    public void buildVertices(VertexConsumer consumer) {
        this.vertex(consumer, this.x0, this.y0, this.u0, this.v0);
        this.vertex(consumer, this.x0, this.y1, this.u0, this.v1);
        this.vertex(consumer, this.x1, this.y1, this.u1, this.v1);
        this.vertex(consumer, this.x1, this.y0, this.u1, this.v0);
    }

    private void vertex(VertexConsumer consumer, int x, int y, float u, float v) {
        consumer.addVertexWith2DPose(this.pose, x, y)
            .setUv(u, v)
            .setColor(this.color)
            .setLineWidth(this.pixelBias);
    }

    @Nullable
    private static ScreenRectangle bounds(
        int x0,
        int y0,
        int x1,
        int y1,
        Matrix3x2fc pose,
        @Nullable ScreenRectangle scissor
    ) {
        ScreenRectangle transformed = new ScreenRectangle(x0, y0, x1 - x0, y1 - y0)
            .transformMaxBounds(pose);
        return scissor == null ? transformed : scissor.intersection(transformed);
    }
}
