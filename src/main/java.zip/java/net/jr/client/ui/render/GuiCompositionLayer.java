package net.jr.client.ui.render;

import com.mojang.blaze3d.textures.FilterMode;
import java.util.function.Consumer;
import net.jr.client.ui.layout.render.UILayoutRenderTarget;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/**
 * Renders a reference canvas using the same scale and coordinate conversion as
 * the controller glyph layer.
 */
public final class GuiCompositionLayer implements AutoCloseable {
    private final UILayoutRenderTarget target = new UILayoutRenderTarget();
    private final int referenceWidth;
    private final int referenceHeight;

    public GuiCompositionLayer(int referenceWidth, int referenceHeight) {
        if (referenceWidth <= 0 || referenceHeight <= 0) {
            throw new IllegalArgumentException("Canvas size must be positive");
        }
        this.referenceWidth = referenceWidth;
        this.referenceHeight = referenceHeight;
    }

    public void submit(
        GuiGraphicsExtractor parentGraphics,
        FilterMode filter,
        float pixelBias,
        Consumer<Canvas> extractor
    ) {
        float resolvedScale = Math.min(
            parentGraphics.guiWidth() / (float)this.referenceWidth,
            parentGraphics.guiHeight() / (float)this.referenceHeight
        );
        if (!Float.isFinite(resolvedScale) || resolvedScale <= 0.0F) {
            resolvedScale = 1.0F;
        }
        final float scale = resolvedScale;
        int targetWidth = Math.max(1, (int)Math.ceil(parentGraphics.guiWidth() / scale));
        int targetHeight = Math.max(1, (int)Math.ceil(parentGraphics.guiHeight() / scale));
        this.target.extractCompositionAndSubmit(
            parentGraphics,
            targetWidth,
            targetHeight,
            1,
            0.0F,
            0.0F,
            scale,
            scale,
            filter,
            pixelBias,
            canvasGraphics -> extractor.accept(new Canvas(canvasGraphics, scale))
        );
    }

    public static final class Canvas {
        private final GuiGraphicsExtractor graphics;
        private final float scale;

        private Canvas(GuiGraphicsExtractor graphics, float scale) {
            this.graphics = graphics;
            this.scale = scale;
        }

        public GuiGraphicsExtractor graphics() {
            return this.graphics;
        }

        public float toCanvasX(float viewportX) {
            return viewportX / this.scale;
        }

        public float toCanvasY(float viewportY) {
            return viewportY / this.scale;
        }
    }

    @Override
    public void close() {
        this.target.close();
    }
}
