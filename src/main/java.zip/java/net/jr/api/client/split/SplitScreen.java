package net.jr.api.client.split;

import net.jr.client.runtime.ClientRuntime;
import net.jr.client.runtime.input.InputDeviceRouter;

public final class SplitScreen {
    private static volatile boolean requireMultipleControllersForJoin = true;

    private SplitScreen() {
    }

    public static boolean isActive() {
        return ClientRuntime.INSTANCE.viewports().presentedCount() >= 2;
    }

    public static boolean requiresMultipleControllersForJoin() {
        return requireMultipleControllersForJoin;
    }

    public static void setRequireMultipleControllersForJoin(boolean required) {
        requireMultipleControllersForJoin = required;
    }

    public static int requiredControllerCountForJoin() {
        return requireMultipleControllersForJoin ? 2 : 1;
    }

    public static boolean hasRequiredControllerCountForJoin() {
        return InputDeviceRouter.connectedGamepads().size() >= requiredControllerCountForJoin();
    }
}
