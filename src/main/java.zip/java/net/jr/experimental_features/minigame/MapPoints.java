package net.jr.experimental_features.minigame;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapPoints {

    public static final MapPoints INSTANCE = new MapPoints();

    private final Map<PointGroup, List<PointPos>> pointsMap;

    private MapPoints() {
        this.pointsMap = new HashMap<>();

        this.createpointsmaps();
    }

    private void createpointsmaps(){
        List<PointPos> centralSpawns = new ArrayList<>();
                centralSpawns.add(new PointPos(213,69,-220));
                centralSpawns.add(new PointPos(215,69,-224));
                centralSpawns.add(new PointPos(219,69,-226));
                centralSpawns.add(new PointPos(223,69,-224));
                centralSpawns.add(new PointPos(225,69,-220));
                centralSpawns.add(new PointPos(223,69,-216));
                centralSpawns.add(new PointPos(219,69,-214));
                centralSpawns.add(new PointPos(215,69,-216));

        List<PointPos> secondarySpawns = new ArrayList<>();





        List<PointPos> centralChest = new ArrayList<>();
                centralChest.add(new PointPos(218, 63, -221));
                centralChest.add(new PointPos(218, 63, -219));
                centralChest.add(new PointPos(220, 63, -219));
                centralChest.add(new PointPos(220, 63, -221));
                centralChest.add(new PointPos(219, 64, -220));

        List<PointPos> secondaryChest = new ArrayList<>();
                secondaryChest.add(new PointPos(187, 72, -226));
                secondaryChest.add(new PointPos(205, 81, -238));
        secondaryChest.add(new PointPos(232, 79, -245));
        secondaryChest.add(new PointPos(250, 67, -243));
        secondaryChest.add(new PointPos(244, 80, -195));
        secondaryChest.add(new PointPos(235, 78, -187));
        secondaryChest.add(new PointPos(217, 66, -183));
        secondaryChest.add(new PointPos(191, 78, -193));


        this.pointsMap.put(PointGroup.SPAWN_CENTRAL,centralSpawns);
        this.pointsMap.put(PointGroup.SPAWN_SECONDARY,secondarySpawns);
        this.pointsMap.put(PointGroup.CHEST_CENTRAL,centralChest);
        this.pointsMap.put(PointGroup.CHEST_SECONDARY,secondaryChest);
    }

    public List<PointPos> getPoints(PointGroup group) {
        return this.pointsMap.getOrDefault(group, new ArrayList<>());
    }
}
